import requests
import bs4
import json
import pymysql
from datetime import datetime

def getMovie():
	date = str(datetime.now())
	date_nobar = date[:10].replace("-", "")
	MovieLists = []	
	MovieCodes = []	
	T_IDs = ['T0433', 'T0071']
	
	url = "http://ticket.movie.naver.com/AsyncRequest/GetMovie.aspx"
	headers = {
	'Host': 'ticket.movie.naver.com',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36',
	'Accept-Encoding': 'gzip, deflate',
	'Accept': '*/*',
	'Connection': ',keep-alive',
	'Content-Length': '92',
	'Content-Type': 'application/x-www-form-urlencoded'
	}
	for T_ID in T_IDs:
		data = {'CMD':'MLIST',
		'FLAG':'0',
		'M_ID':'M000067591',
		'T_ID': T_ID,
		'FE_FLAG':'0',
		'PLAY_DT': date
		}
		r = requests.post(url, headers=headers, data=data)
		Moviejson = r.json()
		MovieList = [Moviejson[i]['m3'] for i, moviename in enumerate(Moviejson)]
		MovieCode = [Moviejson[i]['m2'] for i, moviename in enumerate(Moviejson)]
		# print(MovieList)
		# print(MovieCode)
		MovieLists.append(MovieList)
		MovieCodes.append(MovieCode)
	# MovieLists.append(getMovieCGV())

	return MovieLists, MovieCodes

def getMovieCGV():
	date = str(datetime.now())[:10].replace("-", "")
	MovieCGV = []
	url = "http://www.cgv.co.kr/common/showtimes/iframeTheater.aspx?areacode=204&theatercode=0079&date="+date

	r = requests.get(url)
	# print(r.text
	soup = bs4.BeautifulSoup(r.text, "html.parser")

	for moviename in soup.select('div.info-movie > a > strong'):
		MovieCGV.append(moviename.get_text().strip())

	return MovieCGV

def getMovieposter(MovieCodes):
	MoviePosters = []
	MovieScores = []
	MovieNumCode = []
	url = "http://ticket.movie.naver.com/AsyncRequest/GetMovie.aspx"
	headers = {
	'Host': 'ticket.movie.naver.com',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36',
	'Accept-Encoding': 'gzip, deflate',
	'Accept': '*/*',
	'Connection': ',keep-alive',
	'Content-Length': '92',
	'Content-Type': 'application/x-www-form-urlencoded'
	}
	for MovieCode in MovieCodes:
		data = {'CMD':'NHN_POSTER', 'M_ID': MovieCode}
		r = requests.post(url, headers=headers, data=data)
		r_split = r.text.split('|')
		MovieScores.append(r_split[1])
		MoviePosters.append(r_split[0])
		MovieNumCode.append(r_split[-1].split('/')[-1].split('_')[0])

	return MoviePosters, MovieScores, MovieNumCode

def getMovieDetail(MovieCodes):
	MovieStorys = []
	MovieReleases = []
	MovieDirectors = []
	#(.story_area)
	for MovieCode in MovieCodes:
		url = "http://movie.naver.com/movie/api/yes24/movieLink.nhn?M_CODE="+MovieCode
		r = requests.get(url)
		soup = bs4.BeautifulSoup(r.text, "html.parser")
		for story in soup.select('.story_area > p.con_tx'):
			story = story.get_text().strip().replace("\'", "\\'")
			MovieStorys.append(story)

		releases = soup.select('dd > p > span > a')[::5]
		for release in soup.select('dd > p > span > a[href*="open=2018"]'):
			if len(release['href'].split('=')[-1])==4:
				continue
			else :
				MovieReleases.append(release['href'].split('=')[-1])

		for director in soup.select('.step2 + dd > p > a'):
			MovieDirectors.append(director.get_text())

	return MovieStorys, MovieReleases, MovieDirectors


def getMovieTeaser(MovieNumCodes):
	MovieTeasers = []
	MovieTeaser = []
	for MovieNumCode in MovieNumCodes:
		url = "https://movie.naver.com/movie/bi/mi/photoView.nhn?code="+MovieNumCode
		r = requests.get(url)
		soup = bs4.BeautifulSoup(r.text, "html.parser")
		
		for teaser in soup.select('._list'):
			# print(teaser['data-json'])
			teaserjson = json.loads(teaser['data-json'])
			MovieTeaser.append(teaserjson['fullImageUrl665px'])
		MovieTeasers.append(MovieTeaser)
		MovieTeaser = []	
	return MovieTeasers



def remove_duplicates(li):
	my_set = set()
	res = []
	for e in li:
		if e not in my_set:
			res.append(e)
			my_set.add(e)
	return res

def getMovieRate(MovieNumCode):
	# MovieLists = remove_duplicates(MovieLists[0]+MovieLists[1])
	rates = []
	MovieRate = []
	codes = []
	url = 'https://movie.naver.com/movie/running/current.nhn?view=list&tab=normal&order=reserve'
	r = requests.get(url)
	soup = bs4.BeautifulSoup(r.text, "html.parser")
	
	for rate in soup.select('div.b_star > span.num'):
		rates.append(rate.get_text())

	for code in soup.select('.tit > a'):
		code = code.get('href')
		codes.append(code.split('=')[-1])
		# for Movie in MovieLists:
		# 	print(rate, Movie)
		# 	# print(rate in Movie)
		# 	if rate in Movie:
		# 		print(rate)
		# 		rates.append(rate)
	for idx, code in enumerate(codes):
		# print(idx, mnc, codes[idx])
		# print(codes)
		if code in MovieNumCode:
		# 	print(mnc)
			# print(codes[idx])
			MovieRate.append(rates[idx])
			# print(rate[idx])
	# print(MovieLists)
	# print(rates)
	return MovieRate



def getMovieTime(MovieCodes):
	date = str(datetime.now())
	date_nobar = date[:10].replace("-", "")
	T_IDs = ['T0433', 'T0071']

	MovieEnd = []
	MovieStart = []
	MovieCinema = []

	MovieEnds = []
	MovieStarts = []
	MovieCinemas = []
	
	url = "http://ticket.movie.naver.com/AsyncRequest/GetPlayTime.aspx"
	headers = {
	'Host': 'ticket.movie.naver.com',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36',
	'Accept-Encoding': 'gzip, deflate',
	'Accept': '*/*',
	'Connection': ',keep-alive',
	'Content-Length': '92',
	'Content-Type': 'application/x-www-form-urlencoded'
	}
	for MovieCode in MovieCodes: #영화별
		for T_ID in T_IDs: #영화관
			data = {'CMD':'PLAYTIME_TLIST',
			'M_ID': MovieCode,
			'T_LIST': T_ID,
			'PLAY_DT': date
			}
			r = requests.post(url, headers=headers, data=data)
			Moviejson = r.json()
			# MovieList = [Moviejson[i]['m3'] for i, moviename in enumerate(Moviejson)]
			# MovieStart = Moviejson[0][11]
			MovieEnd.append([Moviejson[i][13]+':00' for i, movie in enumerate(Moviejson)])
			MovieStart.append([Moviejson[i][11][:2]+':'+Moviejson[i][11][2:5]+':00' for i, movie in enumerate(Moviejson)])
			MovieCinema.append([Moviejson[i][8][0] for i, movie in enumerate(Moviejson)])

		MovieEnds.append(MovieEnd)
		MovieStarts.append(MovieStart)
		MovieCinemas.append(MovieCinema)
		MovieEnd = []
		MovieStart = []
		MovieCinema = []
			# print(MovieCinema)
	return MovieStarts, MovieEnds, MovieCinemas

	
def Mysql(sql):
	conn = pymysql.connect(host='localhost', user='root', password='moamovie', db='moaDB', charset='utf8')
	curs = conn.cursor()
	# sql = "select * from movie_info"
	curs.execute(sql)
	conn.commit()

	rows =curs.fetchall()

	print(rows)
	conn.close()

if __name__ == '__main__':
	# idx 0 : nav-lottecinema changwon
	# idx 1 : nav-megabox changwon
	# idx 2 : cgv changwon the city
	# print(MovieList, MovieCode)
	MovieList, MovieCode = getMovie()
	MovieList = remove_duplicates(MovieList[0]+MovieList[1])
	MovieCode = remove_duplicates(MovieCode[0]+MovieCode[1])
	# print(MovieCode)
	MoviePoster, MovieScore, MovieNumCode = getMovieposter(MovieCode)
	MovieRate = getMovieRate(MovieNumCode)
	MovieStory, MovieRelease, MovieDirector = getMovieDetail(MovieCode)
	MovieTeaser = getMovieTeaser(MovieNumCode)
	MovieStart, MovieEnd, MovieAuditorium = getMovieTime(MovieCode)	

	print(len(MovieList))
	print(len(MovieDirector))
	print(len(MovieScore))
	print(len(MovieRelease))
	print(len(MovieStory))
	print(len(MoviePoster))
	print(len(MovieRate))
	sql = 'delete from movie_info'
	Mysql(sql)	
	sql = 'delete from teaser'
	Mysql(sql)
	sql = 'delete from ticket_info'	
	Mysql(sql)
	for idx, movie in enumerate(MovieList):
		sql = '''insert into movie_info values(%s,'%s','%s',%s,'%s','%s','%s',%s)'''%(idx+1, MovieList[idx], MovieDirector[idx], MovieScore[idx], MovieRelease[idx], MovieStory[idx], MoviePoster[idx], MovieRate[idx])
		Mysql(sql)

	for idx, movie in enumerate(MovieList):
		for teaser in MovieTeaser[idx]:
			sql = '''insert into teaser values('%s', '%s', 'image')'''%(movie, teaser)
			print(sql)	
			Mysql(sql)

	for idx, movie in enumerate(MovieList):
		for x, aud in enumerate(MovieAuditorium[idx]):
			for y in range(len(aud)):
				if (x == 0):
					sql = '''insert into ticket_info values('%s', %s, '%s', '%s', '메가박스')'''%(movie, MovieAuditorium[idx][x][y], MovieStart[idx][x][y], MovieEnd[idx][x][y])
					Mysql(sql)
					# print(sql)
				else :
					sql = '''insert into ticket_info values('%s', %s, '%s', '%s', '롯데시네마')'''%(movie, MovieAuditorium[idx][x][y], MovieStart[idx][x][y], MovieEnd[idx][x][y])
					Mysql(sql)		
	# Movie
	# print(MoviePoster, MovieScore)
	# http://www.cgv.co.kr/reserve/show-times/?areacode=204&theaterCode=0023&date=20180515
	# http://www.cgv.co.kr/theaters/?theaterCode=0079
	# http://www.megabox.co.kr/?menuId=theater-detail&region=55&cinema=6421

	# http://ticket.movie.naver.com/AsyncRequest/GetMovie.aspx
	# http://ticket.movie.naver.com/AsyncRequest/GetPlayDate.aspx
	# http://ticket.movie.naver.com/AsyncRequest/GetPlayTime.aspx
