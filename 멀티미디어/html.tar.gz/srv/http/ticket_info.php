<!DOCTYPE html>
<html>
	<head>
		<meta charset='utf-8'>
		<link rel='stylesheet' type='text/css' href='assets/css/ticket_info.css' />
		<link rel='stylesheet' type='text/css' href='assets/css/default.css' />
	</head>
	<body>
		<?php
			$title = $_GET['title'];
			$mysql = mysqli_connect('localhost', 'moauser', 'moamoa', 'moaDB');
			if(!$mysql) die("Error : Can't acess tp DB" . mysqli_error());
		?>
		<div id = "logo">
			<a href='index.php'><img src=./images/logo.png id='logo'></a>
		</div>

		<div class="container">
			<div class="info-box">
				<img class="image-box" src=<?php echo($_GET['src']); ?>>
				<div class="info"><?php echo($title); ?></div>
				<div class="info"><?php echo("평 점 : <span class='starRating'><span style='width:".($_GET['score']*10)."%'></span></span> ".$_GET['score']); ?></div>
			</div>

			<table width = 100% height = 490px>
				<?php MakeTimeTable($mysql, $title, "롯데시네마"); ?>
				<?php MakeTimeTable($mysql, $title, "메가박스"); ?></div>
				<?php MakeTimeTable($mysql, $title, "cgv"); ?>
			</table>
		</div>

		<footer>
			대표 : 문형진 | 회사주소: 경상남도 창원시 의창구 창원대학로 20 55호관</br>
			이메일문의: 20143124@changwon.ac.kr | <a>고객센터</a> | @Moa Corp.
		</footer>

	</body>
</html>

<?php
			function MakeTimeTable($mysql, $title, $cinema)
			{
				$select_qurry = "SELECT auditorium, time_format(start, '%H:%m'), time_format(end,'%H:%m') from ticket_info where title = \"".$title."\" AND cinema = \"".$cinema."\" ORDER BY auditorium, start";
				$result_set = mysqli_query($mysql, $select_qurry);
				$num  ="";

				if(!$result_set->num_rows) return;

				echo("<tr>\n");
				echo("<td width = 20px>".$cinema."</td>\n");
				echo("<td><div class=\"timetable\">\n");
				if($cinema == '롯데시네마') echo("<form action='http://www.lottecinema.co.kr/LCHS/Contents/Cinema/Cinema-Detail.aspx?divisionCode=1&detailDivisionCode=101&cinemaID=5002'>");
				else if($cinema == '메가박스') echo("<form action='http://www.megabox.co.kr/?menuId=theater-detail&region=55&cinema=6421'>");
				else echo("<form action='http://www.cgv.co.kr/theaters/?theaterCode=0023'>");
				while($row = mysqli_fetch_array($result_set))
				{
					if($num != $row[0])
					{
						if($num !="") echo("<br/>");
						$num = $row[0];
						echo($num."관<br/>\n");
					}
					echo("<button title='~".$row[2]."' href=>".$row[1]."</button>\n");
				}
				echo("</form>");
				echo("</td>\n");
				echo("</tr>\n");
			}
?>
