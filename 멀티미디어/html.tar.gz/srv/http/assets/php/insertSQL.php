<?php
	$title = $_POST['title'];
	$id = $_POST['id'];
	$password = hash("sha256", $_POST['password']);
	$score = $_POST['star-input'];
	$review = $_POST['review'];
	$ip = ip2long($_SERVER['REMOTE_ADDR']);


	$mysql = mysqli_connect('localhost', 'moauser', 'moamoa', 'moaDB');
	$overlap = mysqli_query($mysql, "SELECT * FROM review_info where ip = ".$ip." AND title = \"".$title."\"")->num_rows;

	if(empty($id)||empty($review))
	{
		echo("<script>\n");
		echo("alert(\"ID나 리뷰 내용이 존재하지 않습니다.\");\n");;
		echo("document.location.href=document.referrer;\n");
		echo("</script>\n");
	}
	else if($overlap)
	{
		echo("<script>\n");
		echo("alert(\"이미 댓글을 작성한 ip 입니다\");\n");;
		echo("document.location.href=document.referrer;\n");
		echo("</script>\n");
	}
	else
	{
		$stmt = $mysql->prepare("INSERT INTO review_info VALUES(?, ?, ?, ?, ?, now(), ?)");
	
		$stmt->bind_param("sssisi", $title, $id, $password, $score, $review,$ip);


		$stmt->execute();

		$stmt->close();
		mysqli_close($mysql);
		header('location:'.$_SERVER["HTTP_REFERER"]);
	}
?>
