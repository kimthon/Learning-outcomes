<?php
	$title = $_POST['title'];
	$id = $_POST['id'];
	$password = hash("sha256", $_POST['password']);

	$mysql = mysqli_connect('localhost', 'moauser', 'moamoa', 'moaDB');
	
	$stmt = $mysql->prepare("DELETE FROM review_info WHERE title=? AND id=? AND password=?");

	$stmt->bind_param("sss", $title, $id, $password);
	$stmt->execute();
	$delCheck = $mysql->affected_rows;

	$stmt->close();
	mysqli_close($mysql);

	if(!$delCheck)
	{
		echo("<script>\n");
		echo("alert(\"비밀번호가 일치하지 않습니다.\");\n");;
		echo("document.location.href=document.referrer;\n");
		echo("</script>\n");
	}
	else header('location:'.$_SERVER["HTTP_REFERER"]);
?>
