var slideIndex = 1;
var slides = document.getElementsByClassName("mySlides");
slides[0].style.display = 'inline-block';

function showSlides(n)
{
	var i;
	slides[slideIndex-1].style.display = 'none';
	slideIndex += n;

	if(slideIndex > slides.length) {slideIndex = 1}
	else if(slideIndex < 1) {slideIndex = slides.length}
	
	slides[slideIndex-1].style.display = 'inline-block';
}
