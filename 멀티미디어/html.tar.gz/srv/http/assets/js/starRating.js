$result = $('.star-input output>b');
$('.star-input').find('#p10').attr('checked', true);
$result.text(10);

var starRating = function(){
	$(document).on("change", ".input > input", function() {
		$result.text($(this).next().text());
	});
  };

starRating();
