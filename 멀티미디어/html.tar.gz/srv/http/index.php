<!DICTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="assets/css/main.css" />
		<link rel="stylesheet" type="text/css" href="assets/css/default.css" />
		<link rel="stylesheet" type"text/css" href="assets/css/starRating.css" />
		<script type = "text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
	</head>
	<body>
		<div id = "logo">
			<a href=./index.php><img id = "logo" src=images/logo.png id="logo"></a>
		</div>

		<!--php 함수를 통해 DB에서 불러온값 만큼 생성-->
		<?php
			Make_BIB();
		?>

		<footer>
			대표 : 문형진 | 회사주소: 경상남도 창원시 의창구 창원대학로 20 55호관</br>
			이메일문의: 20143124@changwon.ac.kr | <a>고객센터</a> | @Moa Corp.
		</footer>
	</body>
</html>

<?php
			function Make_BIB()
			{
				$mysql = mysqli_connect("localhost", "moauser", "moamoa", "moaDB");
				if(!$mysql) die("Error : Can't access to DB" . mysqli_error());

				$select_query = "SELECT poster_src, title,rate, score FROM movie_info ORDER BY rank";
				$result_set = mysqli_query($mysql, $select_query);
	
				echo("<form method=get action='movie_info.php' style='width=100%'>\n");

				while($row = mysqli_fetch_array($result_set))
				{
					echo("\t<div class ='brif-info-box'>\n");
					echo("\t\t<input class='image-box' type='image' src='".$row[0]."' width=100%  name = 'title' value='".$row[1]."'/>\n");
					echo("\t\t<div class='info-box'>예매율:".$row[2]."%</div>\n");
				   	echo("\t\t<div class='info-box'>평  점:");
					echo("<span class='starRating'><span style='width:".($row[3]*10)."%'></span></span>\n");
					echo($row[3]);
					echo("</div>\n");
					echo("\t</div>\n");
				}

				echo("</form>\n\n");
				mysqli_close($mysql);
			}
?>
