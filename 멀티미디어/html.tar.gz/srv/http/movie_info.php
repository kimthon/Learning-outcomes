<!DOCTYPE html>
<html>
	<head>
		<meta charset='utf-8'>
		<link rel='stylesheet' type='text/css' href='assets/css/movie_info.css' />
		<link rel='stylesheet' type='text/css' href='assets/css/default.css' />
		<script  src="http://code.jquery.com/jquery-latest.min.js"></script>
	</head>

	<body>
		<?php
			$title = $_GET['title'];
			$mysql = mysqli_connect('localhost', 'moauser', 'moamoa', 'moaDB');
			if(!$mysql) die("Error : Can't acess tp DB" . mysqli_error());

			$movie_info = get_info($mysql, $title);
		?>
		<div id = 'logo'>
			<a href='index.php'><img src=./images/logo.png id='logo'></a>
		</div>

		<div class='container'>
			<div style="display:flex; flex-direction:row;border:0px">
				<img class = "poster" src="<?php echo($movie_info[0]); ?>"/>

				<div class = 'brif'>
					<div><?php echo($movie_info[1]) ?></div>
					<div>평  점: <?php echo("<span class='starRating'><span style='width:".($movie_info[2]*10)."%'></span></span> ".$movie_info[2]); ?></div>
					
					<div>감  독:<?php echo($movie_info[3]) ?></div>
					<div>개봉일:<?php echo($movie_info[4]) ?></div>
					<div>흥  행: 예매율 <?php echo($movie_info[5]); ?>위</div>
					<p style="height:100%">줄거리 : <?php echo($movie_info[6]) ?></p>
				</div>
			</div>
			<form method=get action='ticket_info.php'>
				<input type='hidden' name='src' value="<?php echo($movie_info[0]); ?>" >
				<input type='hidden' name='score' value="<?php echo($movie_info[2]); ?>" >
				<input type='image' class='button'  src='images/button.jpg' name='title' value="<?php echo($movie_info[1]);?>">
			</form>

			<div id = 'teaser'>
			<?php
				make_slides($mysql, $title);
			?>

			</div>
	
			<div>

			<hr style="margin-top:5px;margin-bottom:5px;">
			
			<form method=post action='assets/php/insertSQL.php'>	
				<table width = 100%; style="margin:auto">
					<tr>
					<input type="hidden" name="title" value=<?php echo('"'.$title.'"');?>>
						<td width=100px;><input maxlength=10 type="text" name="id" placeholder="닉네임"></td>
						<td rowspan='3'><textarea maxlength=255 class='review' name = "review" rows="4"></textarea></td>
						<td rowspan='3'width=80px><input id='submit'type="image" src='images/submit.gif'></td>
					</tr>
			
					<tr>
						<td><input type="Password" name="password" placeholder="비밀번호"></td>
					</tr>
	
					<tr>
						<td>
							<?php
								make_starScore();
							?>
						</td>
					</tr>
				</table>
			</form>
			<hr style="margin-top:5px; margin-bottom:5px;">
			<?php
				make_review($mysql, $title);
			?>	
			<footer>
			대표 : 문형진 | 회사주소: 경상남도 창원시 의창구 창원대학로 20 55호관</br>
			이메일문의: 20143124@changwon.ac.kr | <a>고객센터</a> | @Moa Corp.
			</footer>
	</body>
</html>

<script type='text/javascript' src='assets/js/slides.js'></script>
<script type='text/javascript' src='assets/js/starRating.js'></script>

<?php
		function get_info($mysql, $title)
		{
			$select_qurry = "SELECT poster_src, title, score, director, realese, rank,summary from movie_info where title = \"".$title."\"";
			$result_set = mysqli_query($mysql, $select_qurry);
			return mysqli_fetch_array($result_set);
		}
	
		function make_review($mysql, $title)
		{
			$select_qurry = "SELECT score, review, id, date_format(date, '%y-%m-%d %h:%i:%s') from review_info where title=\"".$title."\"";
			$result_set = mysqli_query($mysql, $select_qurry);

			echo("<table class='review_table' width=100%>\n");
			while($row = mysqli_fetch_array($result_set))
			{
				echo("\t<tr>\n");
				echo("<td rowspan='2'><span class='starRating'><span style='width:".($row[0]*10)."%'></span></span></td>"); 
				echo("\t\t<td colspan='2'>".$row[1]."</td>\n");
				echo("<form method=post action='assets/php/delReview.php'>");
				echo("\t\t<td rowspan='2'><input type='password' name='password' placeholder='비밀번호'>\n");
				echo("\t\t<input type='hidden' name='id' value='".$row[2]."'>\n");
				echo("\t\t<input type='hidden' name='title' value='".$title."'>\n");
				echo("\t\t<button class='delbutton'>댓글삭제</button></td>");
				echo("</form>");
				echo("\t</tr>\n");
				echo("\t<tr>\n");
				echo("\t\t<td width=100%>".$row[2]." | ".$row[3]."</td>\n");
				echo("\t</tr>\n");
			}
			echo("</table>\n");
		}

		function make_slides($mysql, $title)
		{
			$select_qurry = "SELECT src from teaser  where title ='".$title."'";
			
			$result_set = mysqli_query($mysql, $select_qurry);
			echo("<div class='slideshow-container'>\n");

			while($row = mysqli_fetch_array($result_set))
			{
				echo("\t<div class='mySlides fade'>\n");
				echo("\t\t<img src='".$row[0]."'>\n");
				echo("\t</div>\n\n");
			}

			echo("\t<a class='prev' onclick='showSlides(-1)'>&#10094;</a>\n");
			echo("\t<a class='next' onclick='showSlides(1)'>&#10095;</a>\n");
			echo("</div>\n");
		}

		function make_starScore()
		{
			echo("<span class='star-input'>\n");
			echo("<span class='input'>\n");
			for($i = 1; $i <=10; $i++)
			{
				echo("<input type='radio' name='star-input' id='p".$i."' value='".$i."'><label for='p".$i."'>".$i."</label>\n");
			}
			echo("</span>\n");
			echo("<output for='star-input'><b>0</b>점</output>\n");
			echo("</span>\n");
		}
?>
