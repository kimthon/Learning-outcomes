import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class xLangPrinter {
	Element root;
	public xLangPrinter(Element e) {
		root = e;
	}

	public void printNode() {
		printNode(root);
	}
	private void printNode(Node e) {
		String name = e.getNodeName();
		if (name.equals("xLang18")) { 
			//System.out.println("i'm in <xLang18>...");
			Node child = e.getFirstChild();
			printNode(child);
			while ((child = child.getNextSibling()) != null)
				printNode(child);
		}
		else if (name.equals("Author")) {
			//System.out.println("i'm in <Author>...");
			System.out.println("Author: " + e.getTextContent());
		}
		else if (name.equals("Function")) {
			printNode(e.getFirstChild());
			printNode(e.getFirstChild().getNextSibling());
			if (e.getFirstChild().getNextSibling().getNextSibling() != null)
				printNode(e.getFirstChild().getNextSibling().getNextSibling());
		}
		else if (name.equals("Fname")) {
			System.out.print(e.getTextContent());
		}
		else if (name.equals("Param")) {
			Node child = e.getFirstChild();
			System.out.print("(");
			while (child != null) {
				printNode(child);
				System.out.print(",");
				child = child.getNextSibling();
			}
			System.out.println(")");
		}
		else if (name.equals("Vname")) {
			System.out.print(e.getTextContent());
		}
		else if (name.equals("Num")) {
			System.out.print(e.getTextContent());
		}
		else if (name.equals("Statement")) {
			Node child = e.getFirstChild();
			System.out.print("{");
			while (child != null) {
				printNode(child);
				System.out.println(";");
				child = child.getNextSibling();
			}
			System.out.println("}");
		}
		else if (name.equals("Assign")) {
			Node child = e.getFirstChild();
			printNode(child);
			System.out.print(" = ");
			printNode(child.getNextSibling());
		}
		else if (name.equals("If")) {
			System.out.print("if (");
			printNode(e.getFirstChild());
			System.out.print(") then {");
			printNode(e.getFirstChild().getNextSibling());
			System.out.println("}");
			if (e.getFirstChild().getNextSibling().getNextSibling() != null) {
				System.out.print("else {");
				printNode(e.getFirstChild().getNextSibling().getNextSibling());
				System.out.println("}");
			}
		}
		else if (name.equals("EQ")) {
			printNode(e.getFirstChild());
			System.out.print(" == ");
			printNode(e.getFirstChild().getNextSibling());
		}
		
		//�̷������� ��ӵ˴ϴ�...

	}



	public void printAll() {
		printAll(root, 0);
	}
	private void printAll(Node node, int indent) {
		if (node == null) return;
		NodeList nodes = node.getChildNodes();
		for (int c = 0; c < nodes.getLength(); c++) {
			for (int i=0; i<indent; i++)
				System.out.print(" ");
			System.out.print(nodes.item(c).getNodeName());
			if (nodes.item(c) instanceof Text) {
				//Text t = (Text)nodes.item(c);
				//System.out.print(" \"" + t.getData() + "\"");
				System.out.print(" \"" + nodes.item(c).getTextContent() + "\"");
			}
			System.out.println();
			printAll(nodes.item(c), indent+2);
		}
	}

}